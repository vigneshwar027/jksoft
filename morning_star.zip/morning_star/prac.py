for x in range(5):
    for y in range(2):
        for z in range(2):
            print(y,z)